﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.SqlTypes;
using System.IO;

namespace DBA_FileStream_Exmple
{
    public partial class Form1 : Form
    {
        DataTable DatTable_FileLIstNames;
        public Form1()
        {
            InitializeComponent();

            SqlConnection conn = new SqlConnection();

            string Constr = ConfigurationManager.ConnectionStrings["FS_Exe"].ConnectionString.ToString();

            conn.ConnectionString = Constr;

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            conn.Open();
            
            //TODO: Write a correct query to fetch the photo FileName and the photo blob Data
            cmd.CommandText = "select DocumentGUID , DocumentName, DocumentFile from BusinessDocuments ";

            SqlDataReader reader = cmd.ExecuteReader();
             DatTable_FileLIstNames = new DataTable();
            DatTable_FileLIstNames.Load(reader);

            listBoxFiles.DataSource = DatTable_FileLIstNames;

            //TODO: Write the column name to dislay in the ListBox
            listBoxFiles.DisplayMember = "DocumentName";
         
        }

        private void listBoxFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Get the Selected Row index
            int selectedindex = listBoxFiles.SelectedIndex;

            //Get The Photo varBinary Data
            Byte[] data = new Byte[0];

            //TODO: Replace the "filedata" with the Column name of the Image Blob
            data = (Byte[])(DatTable_FileLIstNames.Rows[selectedindex]["DocumentFile"]);

            MemoryStream mem = new MemoryStream(data);
            pictureBoxPhoto.Image = Image.FromStream(mem);
        }
    }
}
